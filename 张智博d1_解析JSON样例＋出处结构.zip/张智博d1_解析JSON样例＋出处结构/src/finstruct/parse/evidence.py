"""出处（evidence）结构的唯一定义处。

这个模块回答一个问题：**下游凭什么相信一个字段值？**

设计受三条硬约束支配，都来自团队 14 天表的明文规定：

1. **D3：禁止事后按数字搜索补出处。**
   所以 bbox 只能在解析阶段生成、随数据一路传给下游，不能等抽取完了再回原文搜索匹配。
   本模块产出的每个 block / cell 都自带走坐标。

2. **D10：防同名串证据。**
   所以 doc_id 由**文件内容哈希**派生，不依赖文件名。
   两份都叫「公告.pdf」的不同文件，会得到不同的 doc_id，证据不会互串。

3. **指标：出处命中率按「区域」和「单元格」分开统计，缺出处计失败。**
   所以 block 级（区域）和 cell 级（表格单元格）是两套独立坐标，
   表格里的值必须能定位到 row/col，不能只给一个区域框顶替。

坐标系约定（必须与陈家浩的页面渲染端对齐，D1 冻结后不得单方面修改）：
- 单位：PDF point（1 pt = 1/72 英寸），与 pdfplumber 输出一致
- bbox 顺序：[x0, y0, x1, y1]，即 [左, 上, 右, 下]
- 原点：页面**左上角**，y 轴向下为正（与 pdfplumber 的 `top`/`bottom` 一致）
- 页面尺寸随页给出，下游按 `bbox / [width, height]` 归一化后再画高亮
"""
from __future__ import annotations

import hashlib
from typing import Dict, List, Optional

SCHEMA_VERSION = "evidence/0.1"
PARSER_NAME = "finstruct.parse"
PARSER_VERSION = "0.1.0"

# ---------------------------------------------------------------- 枚举值
# 页面形态（逐页判定，不按整份文档判定）
FORM_TEXT = "TEXT"          # 有可用文本层
FORM_SCANNED = "SCANNED"    # 无文本层，需走 OCR
FORM_MIXED = "MIXED"        # 文本层与图像混排，两条通道都跑

# 块角色
ROLE_TITLE = "TITLE"        # 居中标题块（通常是文件大标题）
ROLE_SECTION = "SECTION"    # 章节标题（一、二、(一)(二) 等）
ROLE_BODY = "BODY"
ROLE_HEADER = "HEADER"      # 页眉，移出正文流但保留
ROLE_FOOTER = "FOOTER"      # 页脚
ROLE_FOOTNOTE = "FOOTNOTE"  # 脚注，常承载表格单位说明，不能丢

# 抽取来源通道（出处可核验的前提：说清这段字是从哪条路来的）
SRC_TEXT_LAYER = "TEXT_LAYER"  # pdfplumber 直接读的文本层
SRC_OCR_OS = "OCR_OS"          # 通道 A：系统/离线 OCR
SRC_VLM = "VLM"                # 通道 B：视觉大模型

# 无法取到出处时的原因码（缺出处要能被统计，不能静默）
MISSING_NOT_PARSED = "NOT_PARSED"
MISSING_ILLEGIBLE = "ILLEGIBLE"
MISSING_DEGRADED = "DEGRADED"


# ---------------------------------------------------------------- 标识符
def file_sha256(path: str) -> str:
    """整文件内容哈希。D10 要求它沿链传递，用于校验证据没有串文件。"""
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def make_doc_id(sha: str) -> str:
    """doc_id 由内容哈希派生，**不用文件名** —— 这是 D10「防同名串证据」的实现。"""
    return "d" + sha[:8]


def make_block_id(doc_id: str, page: int, seq: int) -> str:
    """稳定且全局唯一的块标识。同一份文件重复解析，同一块得到同一个 id。"""
    return f"{doc_id}_p{page:03d}_b{seq:05d}"


def make_table_id(doc_id: str, page: int, seq: int) -> str:
    return f"{doc_id}_p{page:03d}_t{seq:03d}"


# ---------------------------------------------------------------- 几何
def bbox_of(chars: List[Dict]) -> List[float]:
    """合并一组字符的包围盒。输入为 pdfplumber 的 char 字典。"""
    x0 = min(c["x0"] for c in chars)
    x1 = max(c["x1"] for c in chars)
    top = min(c["top"] for c in chars)
    bottom = max(c["bottom"] for c in chars)
    return [round(x0, 2), round(top, 2), round(x1, 2), round(bottom, 2)]


def bbox_union(boxes: List[List[float]]) -> List[float]:
    """合并多个矩形。"""
    return [
        round(min(b[0] for b in boxes), 2),
        round(min(b[1] for b in boxes), 2),
        round(max(b[2] for b in boxes), 2),
        round(max(b[3] for b in boxes), 2),
    ]


def area_ratio(boxes: List[List[float]], page_w: float, page_h: float) -> float:
    """矩形并集面积占页面面积的比例。用于形态判定的 text_area_r / img_area_r。"""
    if not boxes:
        return 0.0
    # 归一化网格上做粗略并集，分辨率 200×200 足够判定用
    nx, ny = 200, 200
    grid = bytearray(nx * ny)
    for x0, y0, x1, y1 in boxes:
        cx0 = max(0, min(nx - 1, int(x0 / page_w * nx)))
        cx1 = max(0, min(nx - 1, int(x1 / page_w * nx)))
        cy0 = max(0, min(ny - 1, int(y0 / page_h * ny)))
        cy1 = max(0, min(ny - 1, int(y1 / page_h * ny)))
        for gy in range(cy0, cy1 + 1):
            base = gy * nx
            for gx in range(cx0, cx1 + 1):
                grid[base + gx] = 1
    return sum(grid) / (nx * ny)


# ---------------------------------------------------------------- 构造函数
def make_block(
    doc_id: str,
    page: int,
    seq: int,
    text: str,
    bbox: List[float],
    role: str = ROLE_BODY,
    font_size: Optional[float] = None,
    source: str = SRC_TEXT_LAYER,
    ocr_confidence: Optional[float] = None,
    degraded: bool = False,
    missing_reason: Optional[str] = None,
) -> Dict:
    """构造一个文本块。bbox 是必填 —— 没有坐标的块不应产出。"""
    return {
        "block_id": make_block_id(doc_id, page, seq),
        "page": page,
        "type": "TEXT",
        "role": role,
        "text": text,
        "bbox": bbox,
        "font_size": None if font_size is None else round(float(font_size), 2),
        "source": source,
        "ocr_confidence": ocr_confidence,
        "degraded": degraded,
        "missing_reason": missing_reason,
        # 表格字段留空：D1 不解析表格，但结构先冻结，D3/D4 直接往里填
        "table_ref": None,
    }


def make_table_cell(
    doc_id: str,
    page: int,
    table_seq: int,
    row: int,
    col: int,
    text: str,
    bbox: List[float],
    rowspan: int = 1,
    colspan: int = 1,
    is_header: bool = False,
    header_path: Optional[str] = None,
    degraded: bool = False,
) -> Dict:
    """构造一个表格单元格。**cell 级出处与 block 级分开** —— 表格里的值必须能定位到行列。"""
    return {
        "doc_id": doc_id,
        "table_id": make_table_id(doc_id, page, table_seq),
        "page": page,
        "row": row,
        "col": col,
        "rowspan": rowspan,
        "colspan": colspan,
        "is_header": is_header,
        "header_path": header_path,
        "text": text,
        "bbox": bbox,
        "degraded": degraded,
    }


def make_page(
    page: int,
    form: str,
    width: float,
    height: float,
    form_evidence: Dict,
    blocks: List[Dict],
    tables: Optional[List[Dict]] = None,
) -> Dict:
    return {
        "page": page,
        "form": form,
        "width": round(float(width), 2),
        "height": round(float(height), 2),
        "form_evidence": form_evidence,
        "blocks": blocks,
        "tables": tables or [],
    }


def make_document(
    file_name: str,
    sha: str,
    page_count: int,
    pages: List[Dict],
    reading_order: List[str],
    parsed_at: str,
    file_size: Optional[int] = None,
    quality: Optional[Dict] = None,
) -> Dict:
    """构造解析结果的顶层对象。"""
    return {
        "schema_version": SCHEMA_VERSION,
        "doc": {
            "doc_id": make_doc_id(sha),
            "file_name": file_name,
            "file_sha256": sha,
            "file_size": file_size,
            "page_count": page_count,
            "parsed_at": parsed_at,
            "parser": {"name": PARSER_NAME, "version": PARSER_VERSION},
            "coord_system": {
                "unit": "pdf_point",
                "origin": "top_left",
                "bbox_order": ["x0", "y0", "x1", "y1"],
            },
        },
        "pages": pages,
        # 阅读顺序显式输出，不指望下游自己拼
        "reading_order": reading_order,
        "quality": quality
        or {"degraded": False, "degrade_reasons": [], "warnings": []},
    }


# ---------------------------------------------------------------- 自检
REQUIRED_BLOCK_KEYS = ("block_id", "page", "bbox", "source")
REQUIRED_CELL_KEYS = ("table_id", "page", "row", "col", "bbox")


def self_check(doc: Dict) -> Dict:
    """轻量结构自检（不依赖 jsonschema）。

    对应团队指标「输出格式合规率 100%」：不合规的记录必须暴露出来，
    而不是当成功输出。返回 {"ok": bool, "errors": [...]}。
    """
    errs: List[str] = []
    if doc.get("schema_version") != SCHEMA_VERSION:
        errs.append(f"schema_version 应为 {SCHEMA_VERSION}")
    d = doc.get("doc", {})
    for k in ("doc_id", "file_name", "file_sha256", "page_count"):
        if not d.get(k):
            errs.append(f"doc.{k} 缺失")

    seen_ids = set()
    for pg in doc.get("pages", []):
        pno = pg.get("page")
        if not pg.get("width") or not pg.get("height"):
            errs.append(f"page {pno}: 缺少页面尺寸")
        for b in pg.get("blocks", []):
            for k in REQUIRED_BLOCK_KEYS:
                if b.get(k) in (None, ""):
                    errs.append(f"page {pno} block {b.get('block_id')}: 缺 {k}")
            box = b.get("bbox")
            if not (isinstance(box, list) and len(box) == 4):
                errs.append(f"page {pno} block {b.get('block_id')}: bbox 不是 4 元组")
            elif not (box[0] <= box[2] and box[1] <= box[3]):
                errs.append(f"page {pno} block {b.get('block_id')}: bbox 顺序错误")
            bid = b.get("block_id")
            if bid in seen_ids:
                errs.append(f"block_id 重复: {bid}")
            seen_ids.add(bid)
        for t in pg.get("tables", []):
            for c in t.get("cells", []):
                for k in REQUIRED_CELL_KEYS:
                    if c.get(k) in (None, ""):
                        errs.append(f"page {pno} cell: 缺 {k}")

    # reading_order 必须与 block_id 集合一致
    all_ids = {b["block_id"] for pg in doc.get("pages", []) for b in pg.get("blocks", [])}
    ro = set(doc.get("reading_order", []))
    if ro != all_ids:
        missing = all_ids - ro
        extra = ro - all_ids
        if missing:
            errs.append(f"reading_order 漏掉 {len(missing)} 个块")
        if extra:
            errs.append(f"reading_order 含 {len(extra)} 个不存在的块")

    return {"ok": not errs, "errors": errs}
