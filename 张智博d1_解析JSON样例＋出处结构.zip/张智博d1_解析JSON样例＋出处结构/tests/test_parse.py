"""解析层回归测试（D1）。

跑法：
    PYTHONPATH=src .venv/bin/python -m pytest tests/test_parse.py -v

这些用例同时是 D7/D12 需要的回归基线：改动解析代码后必须全绿，
否则说明出处结构被破坏了。
"""
from __future__ import annotations

import json
import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from finstruct.parse import doc_form as df  # noqa: E402
from finstruct.parse import evidence as ev  # noqa: E402
from finstruct.parse import parse_pdf as pp  # noqa: E402
from finstruct.parse import text_layer as tl  # noqa: E402

ROOT = os.path.join(os.path.dirname(__file__), "..")
FIXTURE = os.path.join(ROOT, "附件1通知.pdf")


@pytest.fixture(scope="module")
def parsed():
    if not os.path.exists(FIXTURE):
        pytest.skip("缺少测试用 PDF：附件1通知.pdf")
    return pp.parse_pdf(FIXTURE)


# ------------------------------------------------------------ 出处结构
def test_结构自检通过(parsed):
    r = ev.self_check(parsed)
    assert r["ok"], r["errors"]


def test_每个块都有合法bbox(parsed):
    for pg in parsed["pages"]:
        for b in pg["blocks"]:
            box = b["bbox"]
            assert len(box) == 4
            assert box[0] <= box[2] and box[1] <= box[3], f"{b['block_id']} bbox 顺序错误"
            # 坐标必须落在页面内
            assert -1 <= box[0] and box[2] <= pg["width"] + 1
            assert -1 <= box[1] and box[3] <= pg["height"] + 1


def test_block_id唯一(parsed):
    ids = [b["block_id"] for pg in parsed["pages"] for b in pg["blocks"]]
    assert len(ids) == len(set(ids))


def test_reading_order与块集合一致(parsed):
    ids = {b["block_id"] for pg in parsed["pages"] for b in pg["blocks"]}
    assert set(parsed["reading_order"]) == ids


def test_doc_id由内容哈希派生(parsed):
    """D10 防同名串证据：doc_id 必须来自 sha256，不能来自文件名。"""
    sha = parsed["doc"]["file_sha256"]
    assert parsed["doc"]["doc_id"] == "d" + sha[:8]
    assert parsed["doc"]["doc_id"] not in parsed["doc"]["file_name"]


def test_同一文件重复解析doc_id不变(parsed):
    again = pp.parse_pdf(FIXTURE)
    assert again["doc"]["doc_id"] == parsed["doc"]["doc_id"]
    ids1 = [b["block_id"] for pg in parsed["pages"] for b in pg["blocks"]]
    ids2 = [b["block_id"] for pg in again["pages"] for b in pg["blocks"]]
    assert ids1 == ids2, "同一文件重复解析，block_id 必须稳定"


# ------------------------------------------------------------ 形态判定
def test_文本pdf判定为TEXT(parsed):
    assert all(p["form"] == "TEXT" for p in parsed["pages"]), \
        [p["form"] for p in parsed["pages"]]


def test_形态判据被留痕(parsed):
    for p in parsed["pages"]:
        e = p["form_evidence"]
        assert e["rule"], "必须记录命中了哪条规则"
        assert "text_chars" in e and "thresholds" in e


# ------------------------------------------------------------ 段落切分
def test_不会整页粘成一个块(parsed):
    """回归 D1 踩到的坑：纯按行距切段落，中文公文会整页粘成一块。

    实测附件1通知.pdf 每页应切出多个块；若退化到每页 1 块，说明
    首行缩进那条判据失效了（典型原因是版心用众数估计，缩进行反成众数）。
    """
    for pg in parsed["pages"]:
        assert len(pg["blocks"]) >= 5, \
            f"第{pg['page']}页只有 {len(pg['blocks'])} 块，段落切分可能已失效"


def test_识别出章节标题(parsed):
    roles = [b["role"] for pg in parsed["pages"] for b in pg["blocks"]]
    assert "SECTION" in roles, "应识别出「一、」「(一)」这类章节标题"
    assert roles.count("TITLE") == 1, "整份通知只有 1 个居中大标题"


def test_章节标题不误标正文(parsed):
    """编号段落（如「1.数据结构化提取。从…」）不能被误标成章节标题。"""
    for pg in parsed["pages"]:
        for b in pg["blocks"]:
            if b["role"] == "SECTION":
                assert len(b["text"]) <= tl.SECTION_MAX_CHARS


# ------------------------------------------------------------ 出处自洽
def test_出处自洽_bbox里装的就是声称的文字(parsed):
    """核心用例：把 bbox 内的字符重新取出来拼一遍，必须与 block.text 一致。

    这是下游能按坐标高亮的前提。若这条挂了，抽取层的锚定和展示层的高亮
    全都会歪，而且不会报错——是最危险的一类问题。
    """
    import pdfplumber

    def norm(s):
        return "".join(s.split())

    bad = []
    with pdfplumber.open(FIXTURE) as pdf:
        for pg in parsed["pages"]:
            chars = pdf.pages[pg["page"] - 1].chars or []
            for b in pg["blocks"]:
                x0, y0, x1, y1 = b["bbox"]
                inside = [
                    c for c in chars
                    if x0 - 0.5 <= (c["x0"] + c["x1"]) / 2 <= x1 + 0.5
                    and y0 - 0.5 <= (c["top"] + c["bottom"]) / 2 <= y1 + 0.5
                ]
                rebuilt = tl.join_block_text(tl.cluster_lines(inside))
                if norm(rebuilt) != norm(b["text"]):
                    bad.append((b["block_id"], b["text"][:40], rebuilt[:40]))
    assert not bad, f"出处不自洽的块：{bad[:3]}"


# ------------------------------------------------------------ 降级
def test_非文本页如实降级不伪装成功():
    """D4 的边界要求：读不到就明确降级，不能假装解析成功。

    这里构造一个只有 1 个字符的迷你 PDF，应被判为非 TEXT 且不产出块。
    """
    # 用形态判定函数直接验证规则 3（水印文本 + 大图 → SCANNED）
    class FakePage:
        width = 595.0
        height = 842.0
        chars = [{"x0": 10, "x1": 20, "top": 10, "bottom": 20, "text": "x", "size": 10}]
        images = [{"x0": 0, "top": 0, "x1": 595, "bottom": 842}]

    form, evid = df.judge_page(FakePage())
    assert form in (ev.FORM_SCANNED, ev.FORM_MIXED)
    assert form != ev.FORM_TEXT
    assert evid["rule"] is not None
