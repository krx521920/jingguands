"""出处自洽性检查：块的 bbox 里装的是不是它声称的那段字。

这是对「出处是否正确」最直接的可自动化验证，也是团队指标
「出处命中率」在 D1 阶段能做到的版本（还没有人工标注，
所以先验证自洽性：坐标与文本必须彼此对应）。

做法：把 bbox 内的字符重新取出来拼一遍，与 block.text 比对。
若两者不一致，说明坐标和文本脱节 —— 下游按坐标高亮会框错地方。

用法：
    python tools/check_evidence.py outputs/附件1通知.parse.json 附件1通知.pdf
"""
from __future__ import annotations

import json
import sys

sys.path.insert(0, __import__("os").path.join(__import__("os").path.dirname(__file__), "..", "src"))

from finstruct.parse import text_layer as tl  # noqa: E402


def chars_in_bbox(chars, bbox, pad=0.5):
    """取中心点落在 bbox 内的字符。"""
    x0, y0, x1, y1 = bbox
    out = []
    for c in chars:
        cx = (c["x0"] + c["x1"]) / 2
        cy = (c["top"] + c["bottom"]) / 2
        if x0 - pad <= cx <= x1 + pad and y0 - pad <= cy <= y1 + pad:
            out.append(c)
    return out


def norm(s: str) -> str:
    return "".join(s.split())


def check(parse_json: str, pdf_path: str) -> int:
    import pdfplumber

    doc = json.load(open(parse_json, encoding="utf-8"))
    total = ok = 0
    problems = []

    with pdfplumber.open(pdf_path) as pdf:
        for pg in doc["pages"]:
            page = pdf.pages[pg["page"] - 1]
            chars = page.chars or []
            for b in pg["blocks"]:
                total += 1
                inside = chars_in_bbox(chars, b["bbox"])
                # 按行重排后拼接，与解析时同一套逻辑
                lines = tl.cluster_lines(inside)
                rebuilt = tl.join_block_text(lines)
                if norm(rebuilt) == norm(b["text"]):
                    ok += 1
                else:
                    problems.append(
                        {
                            "block_id": b["block_id"],
                            "page": pg["page"],
                            "claimed": b["text"][:60],
                            "in_bbox": rebuilt[:60],
                            "n_chars_in_bbox": len(inside),
                        }
                    )

    rate = ok / total if total else 0.0
    print(f"块总数        : {total}")
    print(f"出处自洽通过  : {ok}")
    print(f"自洽率        : {rate:.1%}")
    if problems:
        print(f"\n不一致的块（{len(problems)} 个，最多显示 8 个）:")
        for p in problems[:8]:
            print(f"  {p['block_id']}  bbox内字符数={p['n_chars_in_bbox']}")
            print(f"    声称: {p['claimed']!r}")
            print(f"    实取: {p['in_bbox']!r}")
    return 0 if rate == 1.0 else 1


def main() -> int:
    if len(sys.argv) < 3:
        print(__doc__)
        return 2
    return check(sys.argv[1], sys.argv[2])


if __name__ == "__main__":
    raise SystemExit(main())
